from netmiko import ConnectHandler
import time

# Definir los dispositivos
devices = {
    "R1": {
        'device_type': 'cisco_ios',
        'ip': '192.168.239.135',
        'username': 'cisco',
        'password': 'cisco',
        'port': 22
    },
    "R2": {
        'device_type': 'cisco_ios',
        'ip': '192.168.2.2',
        'username': 'cisco',
        'password': 'cisco',
        'port': 22
    },
    "R4": {
        'device_type': 'cisco_ios',
        'ip': '192.168.4.2',
        'username': 'cisco',
        'password': 'cisco',
        'port': 22
    }
}

ping_targets = {
    "R1": ['192.168.2.2', '192.168.4.2'],
    "R2": ['192.168.239.135', '192.168.3.2'],
    "R4": ['192.168.239.135', '192.168.3.2']
}

def connect_to_device(device):
    try:
        connection = ConnectHandler(**device)
        print(f"Conexión SSH establecida con éxito a {device['ip']}")
        return connection
    except Exception as e:
        print(f"Error al conectar a {device['ip']}: {e}")
        return None

def show_ip_interfaces(connection):
    try:
        output = connection.send_command("show ip interface brief")
        return output
    except Exception as e:
        return f"Error: {str(e)}"

def show_cdp_neighbors(connection):
    try:
        output = connection.send_command("show cdp neighbors")
        return output
    except Exception as e:
        return f"Error: {str(e)}"

def ping_routers(connection, routers):
    results = []
    try:
        for router_ip in routers:
            command = f"ping {router_ip}"
            output = connection.send_command(command, delay_factor=2)
            results.append({"ip": router_ip, "result": output})
            time.sleep(1)
        return results
    except Exception as e:
        return [{"ip": "Error", "result": str(e)}]

def get_cpu_usage(connection):
    try:
        output = connection.send_command("show processes cpu sorted")
        return output
    except Exception as e:
        return f"Error: {str(e)}"

def get_memory_usage(connection):
    try:
        connection.send_command("terminal length 0")
        output = connection.send_command("show memory statistics", delay_factor=4, max_loops=100)
        return output
    except Exception as e:
        return f"Error: {str(e)}"

def get_device_version(connection):
    try:
        output = connection.send_command("show version")
        return output
    except Exception as e:
        return f"Error: {str(e)}"

def parse_cpu_usage(cpu_output):
    cpu_data = {
        "five_sec": None,
        "one_min": None,
        "five_min": None,
        "top_processes": []
    }
    try:
        lines = cpu_output.strip().split('\n')
        for line in lines:
            if "CPU utilization" in line:
                parts = line.split(";")
                if len(parts) >= 3:
                    cpu_stats = parts[0].split(":")
                    if len(cpu_stats) >= 2:
                        cpu_percentages = cpu_stats[1].strip().split("/")
                        if len(cpu_percentages) >= 3:
                            cpu_data["five_sec"] = cpu_percentages[0].strip()
                            cpu_data["one_min"] = cpu_percentages[1].strip()
                            cpu_data["five_min"] = cpu_percentages[2].strip()
                break
        # Extraer procesos con mayor uso CPU
        start = False
        for line in lines:
            if "PID" in line and "Runtime(ms)" in line:
                start = True
                continue
            if start and line.strip():
                parts = line.split()
                if len(parts) >= 8:
                    process = {
                        "pid": parts[0],
                        "cpu_5sec": parts[1],
                        "process_name": parts[-1]
                    }
                    cpu_data["top_processes"].append(process)
                    if len(cpu_data["top_processes"]) >= 5:
                        break
    except Exception as e:
        print(f"Error parseando CPU: {e}")
    return cpu_data

def parse_memory_usage(memory_output):
    memory_data = {
        "total": None,
        "used": None,
        "free": None,
        "usage_percent": None
    }
    try:
        lines = memory_output.strip().split('\n')
        for i, line in enumerate(lines):
            if "Processor" in line and "Total" in line:
                parts = lines[i+1].split()
                if len(parts) >= 3:
                    total = int(parts[0])
                    used = int(parts[1])
                    free = int(parts[2])
                    memory_data["total"] = total
                    memory_data["used"] = used
                    memory_data["free"] = free
                    if total > 0:
                        memory_data["usage_percent"] = round((used / total) * 100, 2)
                break
    except Exception as e:
        print(f"Error parseando memoria: {e}")
    return memory_data

def parse_device_version(version_output):
    version_data = {
        "ios_version": None,
        "uptime": None,
        "model": None,
        "serial": None
    }
    try:
        lines = version_output.strip().split('\n')
        for i, line in enumerate(lines):
            if "Cisco IOS Software" in line:
                parts = line.split(", ")
                if len(parts) >= 2:
                    version_data["ios_version"] = parts[2].strip()
            elif "uptime is" in line:
                uptime_parts = line.split("uptime is")
                if len(uptime_parts) >= 2:
                    version_data["uptime"] = uptime_parts[1].strip()
            elif "Model number" in line:
                model_parts = line.split(":")
                if len(model_parts) >= 2:
                    version_data["model"] = model_parts[1].strip()
            elif "Serial Number" in line:
                serial_parts = line.split(":")
                if len(serial_parts) >= 2:
                    version_data["serial"] = serial_parts[1].strip()
    except Exception as e:
        print(f"Error parseando versión: {e}")
    return version_data

def get_device_info(device):
    """Recopila información de dispositivos para el dashboard."""
    connection = connect_to_device(device)
    if not connection:
        return {
            "status": "error",
            "message": f"No se pudo conectar a {device['ip']}",
            "interfaces": [],
            "neighbors": "",
            "ping_results": [],
            "cpu_usage": {},
            "memory_usage": {},
            "device_version": {}
        }
    
    # Obtener datos de interfaces
    interfaces_output = show_ip_interfaces(connection)
    interfaces_list = []
    
    if interfaces_output and "Error" not in interfaces_output:
        # Parsear la salida para obtener datos de interfaces
        lines = interfaces_output.strip().split('\n')
        # Saltar la línea de encabezado
        for line in lines[1:]:
            parts = line.split()
            if len(parts) >= 6:
                interface = {
                    "name": parts[0],
                    "ip_address": parts[1],
                    "status": parts[4],
                    "protocol": parts[5]
                }
                interfaces_list.append(interface)
    
    # Obtener datos de vecinos CDP
    neighbors_output = show_cdp_neighbors(connection)
    
    # Hacer ping a otros routers
    device_name = None
    for name, device_info in devices.items():
        if device_info["ip"] == device["ip"]:
            device_name = name
            break
    
    ping_results = ping_routers(connection, ping_targets.get(device_name, []))
    
    # Obtener datos de recursos
    cpu_output = get_cpu_usage(connection)
    memory_output = get_memory_usage(connection)
    version_output = get_device_version(connection)
    
    # Analizar datos de recursos
    cpu_data = parse_cpu_usage(cpu_output)
    memory_data = parse_memory_usage(memory_output)
    version_data = parse_device_version(version_output)
    
    # Cerrar la conexión
    connection.disconnect()
    
    return {
        "status": "success",
        "device_ip": device['ip'],
        "interfaces": interfaces_list,
        "neighbors": neighbors_output,
        "ping_results": ping_results,
        "cpu_usage": cpu_data,
        "memory_usage": memory_data,
        "device_version": version_data,
        "raw_cpu_output": cpu_output,
        "raw_memory_output": memory_output,
        "raw_version_output": version_output
    }

def show_device_dashboard(device_info):
    """Muestra la información del dispositivo en un formato de dashboard."""
    if device_info["status"] == "error":
        print(f"\n⚠️ ERROR: {device_info['message']}")
        return
    
    print(f"\n===== DASHBOARD DEL DISPOSITIVO {device_info['device_ip']} =====")
    
    # Mostrar información básica del dispositivo
    print("\n🔍 INFORMACIÓN DEL DISPOSITIVO:")
    if device_info["device_version"].get("model"):
        print(f"  Modelo: {device_info['device_version']['model']}")
    if device_info["device_version"].get("ios_version"):
        print(f"  Versión IOS: {device_info['device_version']['ios_version']}")
    if device_info["device_version"].get("uptime"):
        print(f"  Tiempo activo: {device_info['device_version']['uptime']}")
    if device_info["device_version"].get("serial"):
        print(f"  Número de serie: {device_info['device_version']['serial']}")
    
    # Mostrar información de interfaces
    print("\n🌐 INTERFACES IP:")
    print(f"  {'Nombre':<15} {'Dirección IP':<15} {'Estado':<10} {'Protocolo'}")
    print("  " + "-" * 50)
    for interface in device_info["interfaces"]:
        print(f"  {interface['name']:<15} {interface['ip_address']:<15} {interface['status']:<10} {interface['protocol']}")
    
    # Mostrar información de CPU
    print("\n💻 USO DE CPU:")
    if device_info["cpu_usage"].get("five_sec"):
        print(f"  CPU últimos 5 segundos: {device_info['cpu_usage']['five_sec']}")
        print(f"  CPU último minuto: {device_info['cpu_usage']['one_min']}")
        print(f"  CPU últimos 5 minutos: {device_info['cpu_usage']['five_min']}")
        
        print("\n  Top procesos por uso de CPU:")
        for i, proc in enumerate(device_info["cpu_usage"]["top_processes"], 1):
            print(f"    {i}. PID: {proc['pid']}, CPU 5 seg: {proc['cpu_5sec']}%, Proceso: {proc['process_name']}")
    
    # Mostrar información de memoria
    print("\n🧠 USO DE MEMORIA:")
    if device_info["memory_usage"].get("total"):
        print(f"  Total: {device_info['memory_usage']['total']} bytes")
        print(f"  Usado: {device_info['memory_usage']['used']} bytes")
        print(f"  Libre: {device_info['memory_usage']['free']} bytes")
        print(f"  Porcentaje de uso: {device_info['memory_usage']['usage_percent']}%")
    
    # Resultados de ping
    print("\n🔄 RESULTADOS DE PING:")
    for result in device_info["ping_results"]:
        success = "Success rate is" in result["result"]
        status = "✅ ÉXITO" if success else "❌ FALLIDO"
        print(f"  {result['ip']}: {status}")
    
    print("\n" + "=" * 50)

def main():
    while True:
        print("\n=== Selecciona el router para conectarte ===")
        for key in devices.keys():
            print(f"- {key}")
        print("- Dashboard")
        print("- Salir")

        choice = input("Ingresa el nombre del router (R1, R2, R4), 'Dashboard' o 'Salir': ").strip()

        if choice.lower() == 'salir':
            print("Saliendo del programa.")
            break
            
        if choice.lower() == 'dashboard':
            # Recopilar información de todos los dispositivos
            print("\n=== Generando dashboard de todos los dispositivos ===")
            all_devices_info = {}
            for device_name, device_config in devices.items():
                print(f"\nConectando a {device_name}...")
                device_info = get_device_info(device_config)
                all_devices_info[device_name] = device_info
                
            # Mostrar resumen de estado de todos los dispositivos
            print("\n===== RESUMEN DE ESTADO DE RED =====")
            print(f"{'Router':<5} {'IP':<15} {'Status':<10} {'Memoria':<10} {'CPU 5s':<10}")
            print("-" * 55)
            for name, info in all_devices_info.items():
                status = "✅ Online" if info["status"] == "success" else "❌ Offline"
                memory = f"{info['memory_usage'].get('usage_percent', 'N/A')}%" if info["status"] == "success" else "N/A"
                cpu = info["cpu_usage"].get("five_sec", "N/A") if info["status"] == "success" else "N/A"
                print(f"{name:<5} {devices[name]['ip']:<15} {status:<10} {memory:<10} {cpu:<10}")
                
            # Preguntar si quiere ver detalles de algún dispositivo específico
            detail_choice = input("\n¿Deseas ver detalles de algún dispositivo? (Ingresa nombre o 'No'): ").strip()
            if detail_choice.lower() != 'no' and detail_choice in all_devices_info:
                show_device_dashboard(all_devices_info[detail_choice])
                
            continue

        if choice not in devices:
            print("Opción no válida. Intenta de nuevo.")
            continue

        device = devices[choice]
        
        # Preguntar si quiere ver el dashboard o el menú tradicional
        view_choice = input(f"¿Deseas ver el dashboard completo de {choice} o acceder al menú tradicional? (Dashboard/Menú): ").strip().lower()
        
        if view_choice == 'dashboard':
            device_info = get_device_info(device)
            show_device_dashboard(device_info)
            continue
        
        # Continuar con el menú tradicional
        connection = connect_to_device(device)
        if not connection:
            continue

        while True:
            print(f"\n=== Menú de Información de {choice} ({device['ip']}) ===")
            print("1. Mostrar información de IPs (show ip interface brief)")
            print("2. Mostrar vecinos CDP (show cdp neighbors)")
            print(f"3. Hacer ping a otros routers conectados desde {choice}")
            print("4. Mostrar uso de CPU")
            print("5. Mostrar uso de memoria")
            print("6. Mostrar versión del dispositivo")
            print("7. Cambiar de router")
            print("8. Salir")

            option = input("Selecciona una opción (1-8): ").strip()

            if option == '1':
                output = show_ip_interfaces(connection)
                print("\nInformación de interfaces IP:")
                print(output)

            elif option == '2':
                output = show_cdp_neighbors(connection)
                print("\nVecinos CDP:")
                print(output)

            elif option == '3':
                targets = ping_targets.get(choice, [])
                if not targets:
                    print("No hay routers para hacer ping desde este dispositivo.")
                    continue
                ping_results = ping_routers(connection, targets)
                for result in ping_results:
                    print(f"\nPing a {result['ip']}:")
                    print(result['result'])

            elif option == '4':
                cpu_output = get_cpu_usage(connection)
                if "Error" in cpu_output:
                    print(cpu_output)
                else:
                    cpu_data = parse_cpu_usage(cpu_output)
                    print("\nUso de CPU:")
                    print(f"CPU Utilization (5 sec): {cpu_data['five_sec']}")
                    print(f"CPU Utilization (1 min): {cpu_data['one_min']}")
                    print(f"CPU Utilization (5 min): {cpu_data['five_min']}")
                    print("Top 5 procesos por uso de CPU:")
                    for proc in cpu_data["top_processes"]:
                        print(f"PID: {proc['pid']}, CPU 5 sec: {proc['cpu_5sec']}%, Proceso: {proc['process_name']}")

            elif option == '5':
                memory_output = get_memory_usage(connection)
                if "Error" in memory_output:
                    print(memory_output)
                else:
                    memory_data = parse_memory_usage(memory_output)
                    print("\nUso de Memoria:")
                    print(f"Total: {memory_data['total']} bytes")
                    print(f"Usado: {memory_data['used']} bytes")
                    print(f"Libre: {memory_data['free']} bytes")
                    print(f"Porcentaje de uso: {memory_data['usage_percent']}%")
                    
            elif option == '6':
                version_output = get_device_version(connection)
                if "Error" in version_output:
                    print(version_output)
                else:
                    version_data = parse_device_version(version_output)
                    print("\nInformación del dispositivo:")
                    print(f"Versión IOS: {version_data['ios_version']}")
                    print(f"Tiempo activo: {version_data['uptime']}")
                    print(f"Modelo: {version_data['model']}")
                    print(f"Número de serie: {version_data['serial']}")

            elif option == '7':
                print(f"Cerrando conexión con {choice}...")
                connection.disconnect()
                break  # volver al menú de selección

            elif option == '8':
                print("Cerrando conexión y saliendo del programa...")
                connection.disconnect()
                return

            else:
                print("Opción no válida, por favor selecciona entre 1 y 8.")

if __name__ == "__main__":
    main()