from django.shortcuts import render
from .utils import get_device_info

def dashboard(request):
    devices = {
        "R1": {
            'device_type': 'cisco_ios',
            'ip': '192.168.239.135',
            'username': 'cisco',
            'password': 'cisco',
            'port': 22
        },
        "R2": {
            'device_type': 'cisco_ios',
            'ip': '192.168.2.2',
            'username': 'cisco',
            'password': 'cisco',
            'port': 22
        },
        "R4": {
            'device_type': 'cisco_ios',
            'ip': '192.168.4.2',
            'username': 'cisco',
            'password': 'cisco',
            'port': 22
        }
    }

    devices_data = []
    for name, device in devices.items():
        info = get_device_info(device)
        info['name'] = name  # para mostrar el nombre del router en la vista
        devices_data.append(info)

    return render(request, 'dashboard.html', {'devices': devices_data})
