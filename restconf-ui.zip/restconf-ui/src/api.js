import axios from 'axios';

const api = axios.create({
  baseURL: '/restconf/data', // <- usamos proxy para evitar CORS
  headers: {
    'Content-Type': 'application/yang-data+json',
    Accept: 'application/yang-data+json',
  },
  auth: {
    username: 'admin',
    password: 'cisco'
  }
});

export default api;

