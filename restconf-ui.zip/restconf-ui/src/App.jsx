import { useState } from 'react';
import InterfaceList from './components/InterfaceList';
import InterfaceDetail from './components/InterfaceDetail';
import InterfaceForm from './components/InterfaceForm';
import './App.css';

function App() {
  const [selected, setSelected] = useState(null);
  
  return (
    <div className="app-container">
      <header className="app-header">
        <h1>RESTCONF Interfaces UI</h1>
      </header>
      
      <main className="app-main">
        <section className="section">
          <h2 className="section-title">Network Interfaces</h2>
          <InterfaceList onSelect={setSelected} />
        </section>
        
        <section className="section">
          <h2 className="section-title">Interface Details</h2>
          <InterfaceDetail name={selected} />
        </section>
        
        <section className="section">
          <h2 className="section-title">Manage Interface</h2>
          <InterfaceForm selectedInterface={selected} />
        </section>
      </main>
      
      <footer className="app-footer">
        <p>RESTCONF Network Management System</p>
      </footer>
    </div>
  );
}

export default App;