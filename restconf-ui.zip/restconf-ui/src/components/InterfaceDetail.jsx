import { useEffect, useState } from 'react';
import api from '../api';
import './InterfaceDetail.css';

function InterfaceDetail({ name }) {
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!name) return;
    
    setLoading(true);
    setError(null);
    
    api.get(`/ietf-interfaces:interfaces/interface=${name}`)
      .then(res => {
        setDetail(res.data['ietf-interfaces:interface']);
      })
      .catch(err => {
        console.error('Error fetching interface details:', err);
        setError(`Error al cargar los detalles: ${err.message}`);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [name]);

  // Render placeholder states
  if (!name) {
    return (
      <div className="interface-detail empty-state">
        <div className="empty-icon">?</div>
        <p>Selecciona una interfaz para ver detalles</p>
      </div>
    );
  }
  
  if (loading) {
    return (
      <div className="interface-detail loading-state">
        <div className="loading-spinner"></div>
        <p>Cargando detalles de <span className="highlight">{name}</span>...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="interface-detail error-state">
        <div className="error-icon">!</div>
        <p>{error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="retry-button"
        >
          Reintentar
        </button>
      </div>
    );
  }
  
  if (!detail) {
    return (
      <div className="interface-detail empty-state">
        <div className="empty-icon">!</div>
        <p>No se encontraron datos para <span className="highlight">{name}</span></p>
      </div>
    );
  }

  // Obtener la máscara de red en formato CIDR si está disponible
  const getCIDR = (netmask) => {
    if (!netmask) return '';
    
    // Esta es una función simplificada para convertir netmask a CIDR
    const countBits = (mask) => {
      // Convierte 255.255.255.0 a /24, etc.
      const parts = mask.split('.');
      let count = 0;
      for (const part of parts) {
        const num = parseInt(part);
        // Cuenta los bits en cada octeto
        count += num.toString(2).split('1').length - 1;
      }
      return count;
    };
    
    return `/${countBits(netmask)}`;
  };

  return (
    <div className="interface-detail">
      <div className="detail-header">
        <h3>
          <span className="interface-name">{detail.name}</span>
          <span className={`status-indicator ${detail.enabled ? 'enabled' : 'disabled'}`}>
            {detail.enabled ? 'Activa' : 'Inactiva'}
          </span>
        </h3>
        <p className="interface-description">{detail.description || 'Sin descripción'}</p>
      </div>
      
      <div className="detail-divider"></div>
      
      <div className="detail-section">
        <div className="detail-item">
          <span className="detail-label">Tipo:</span>
          <span className="detail-value type-badge">{detail.type.replace('iana-if-type:', '')}</span>
        </div>
      </div>
      
      {detail['ietf-ip:ipv4']?.address?.length > 0 && (
        <div className="detail-section">
          <h4>Direcciones IPv4</h4>
          <ul className="address-list">
            {detail['ietf-ip:ipv4'].address.map((addr, index) => (
              <li key={index} className="address-item">
                <div className="ip-container">
                  <span className="ip-address">{addr.ip}</span>
                  <span className="ip-netmask">{addr.netmask}</span>
                </div>
                <span className="ip-cidr">{getCIDR(addr.netmask)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {detail['ietf-ip:ipv6']?.address?.length > 0 && (
        <div className="detail-section">
          <h4>Direcciones IPv6</h4>
          <ul className="address-list">
            {detail['ietf-ip:ipv6'].address.map((addr, index) => (
              <li key={index} className="address-item ipv6">
                <span className="ip-address">{addr.ip}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {(!detail['ietf-ip:ipv4']?.address?.length && !detail['ietf-ip:ipv6']?.address?.length) && (
        <div className="detail-section no-ip">
          <p>Esta interfaz no tiene direcciones IP configuradas</p>
        </div>
      )}
    </div>
  );
}

export default InterfaceDetail;