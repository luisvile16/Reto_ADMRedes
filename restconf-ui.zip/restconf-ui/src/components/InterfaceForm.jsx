import { useState, useEffect } from 'react';
import api from '../api';
import './InterfaceForm.css';

function InterfaceForm({ selectedInterface, onUpdateSuccess }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    ip: '',
    netmask: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState({ type: '', message: '' });
  const [isEditMode, setIsEditMode] = useState(false);
  const [originalData, setOriginalData] = useState(null);

  // Cargar los datos de la interfaz seleccionada
  useEffect(() => {
    if (selectedInterface) {
      setFormData(prev => ({
        ...prev,
        name: selectedInterface
      }));
      
      // Obtener los detalles de la interfaz para edición
      api.get(`/ietf-interfaces:interfaces/interface=${selectedInterface}`)
        .then(res => {
          const interfaceData = res.data['ietf-interfaces:interface'];
          setOriginalData(interfaceData);
          
          // Extraer los datos relevantes para el formulario
          const ipv4Address = interfaceData['ietf-ip:ipv4']?.address?.[0] || {};
          
          setFormData({
            name: interfaceData.name || '',
            description: interfaceData.description || '',
            ip: ipv4Address.ip || '',
            netmask: ipv4Address.netmask || ''
          });
          
          setIsEditMode(true);
        })
        .catch(() => {
          // Si no se puede obtener la interfaz, probablemente sea nueva
          setFormData({
            name: selectedInterface,
            description: '',
            ip: '',
            netmask: ''
          });
          setIsEditMode(false);
          setOriginalData(null);
        });
    } else {
      // Limpiar el formulario cuando no hay selección
      setFormData({ name: '', description: '', ip: '', netmask: '' });
      setIsEditMode(false);
      setOriginalData(null);
    }
  }, [selectedInterface]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Clear feedback when user starts typing again
    if (feedback.message) {
      setFeedback({ type: '', message: '' });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    const payload = {
      'ietf-interfaces:interface': {
        name: formData.name,
        description: formData.description,
        type: 'iana-if-type:softwareLoopback',
        enabled: true,
        'ietf-ip:ipv4': {
          address: [{ ip: formData.ip, netmask: formData.netmask }]
        },
        'ietf-ip:ipv6': {}
      }
    };

    // Si estamos en modo edición y tenemos datos originales, conservar algunos valores
    if (isEditMode && originalData) {
      payload['ietf-interfaces:interface'].type = originalData.type;
      payload['ietf-interfaces:interface'].enabled = originalData.enabled;
      
      // Preservar IPv6 si existe
      if (originalData['ietf-ip:ipv6']) {
        payload['ietf-interfaces:interface']['ietf-ip:ipv6'] = originalData['ietf-ip:ipv6'];
      }
    }

    // Usar PUT para crear o actualizar la interfaz
    api.put(`/ietf-interfaces:interfaces/interface=${formData.name}`, payload)
      .then(() => {
        setFeedback({
          type: 'success',
          message: isEditMode 
            ? `Interfaz ${formData.name} actualizada con éxito`
            : `Interfaz ${formData.name} creada con éxito`
        });
        
        // Notificar al componente padre sobre la actualización exitosa
        if (onUpdateSuccess) {
          onUpdateSuccess();
        }
        
        // Si no estamos en modo edición, limpiar el formulario
        if (!isEditMode) {
          setFormData({ name: '', description: '', ip: '', netmask: '' });
        }
      })
      .catch((err) => {
        console.error('Error:', err.response?.data || err.message);
        setFeedback({
          type: 'error',
          message: err.response?.data?.detail || `Error al ${isEditMode ? 'actualizar' : 'crear'} la interfaz`
        });
      })
      .finally(() => {
        setIsSubmitting(false);
      });
  };

  const handleCancel = () => {
    if (isEditMode && originalData) {
      // Restaurar datos originales
      const ipv4Address = originalData['ietf-ip:ipv4']?.address?.[0] || {};
      
      setFormData({
        name: originalData.name || '',
        description: originalData.description || '',
        ip: ipv4Address.ip || '',
        netmask: ipv4Address.netmask || ''
      });
    } else {
      // Limpiar el formulario
      setFormData({ name: '', description: '', ip: '', netmask: '' });
    }
    
    setFeedback({ type: '', message: '' });
  };

  return (
    <div className="interface-form-wrapper">
      <form className="interface-form" onSubmit={handleSubmit}>
        <div className="form-header">
          <h3>{isEditMode ? 'Editar Interfaz' : 'Crear Nueva Interfaz Loopback'}</h3>
          <div className="form-divider"></div>
        </div>

        {feedback.message && (
          <div className={`feedback-message ${feedback.type}`}>
            {feedback.type === 'success' ? '✓ ' : '✕ '}
            {feedback.message}
          </div>
        )}

        <div className="form-group">
          <label htmlFor="name">Nombre:</label>
          <input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="ej. Loopback0"
            required
            className="form-input"
            disabled={isEditMode} // Deshabilitar la edición del nombre en modo edición
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Descripción:</label>
          <input
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="ej. Interfaz de administración"
            required
            className="form-input"
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="ip">Dirección IP:</label>
            <input
              id="ip"
              name="ip"
              value={formData.ip}
              onChange={handleChange}
              placeholder="ej. 192.168.1.1"
              required
              className="form-input"
            />
          </div>

          <div className="form-group">
            <label htmlFor="netmask">Netmask:</label>
            <input
              id="netmask"
              name="netmask"
              value={formData.netmask}
              onChange={handleChange}
              placeholder="ej. 255.255.255.0"
              required
              className="form-input"
            />
          </div>
        </div>

        <div className="form-actions">
          <button 
            type="submit" 
            className="submit-button"
            disabled={isSubmitting}
          >
            {isSubmitting 
              ? (isEditMode ? 'Actualizando...' : 'Creando...') 
              : (isEditMode ? 'Actualizar Interfaz' : 'Crear Interfaz')
            }
          </button>
          
          <button 
            type="button" 
            className="cancel-button"
            onClick={handleCancel}
            disabled={isSubmitting}
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  );
}

export default InterfaceForm;