import { useState, useEffect } from 'react';
import api from '../api';
import './InterfaceList.css';

function InterfaceList({ onSelect }) {
  const [interfaces, setInterfaces] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const fetchInterfaces = () => {
    setLoading(true);
    api.get('/ietf-interfaces:interfaces')
      .then(res => {
        const data = res.data['ietf-interfaces:interfaces']?.interface || [];
        setInterfaces(data);
      })
      .catch(error => {
        console.error('Error fetching interfaces:', error);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchInterfaces();
  }, []);

  const handleSelectInterface = (name) => {
    setSelectedItem(name);
    onSelect(name);
  };

  return (
    <div className="interface-list">
      <div className="interface-list-header">
        <h3>Interfaces</h3>
        <button
          onClick={fetchInterfaces}
          disabled={loading}
          className="reload-button"
          aria-label="Refresh interfaces list"
        >
          {loading ? '⏳' : '🔄'} {loading ? 'Cargando...' : 'Actualizar'}
        </button>
      </div>

      {interfaces.length > 0 ? (
        <ul className="interface-items">
          {interfaces.map((intf) => (
            <li
              key={intf.name}
              onClick={() => handleSelectInterface(intf.name)}
              className="interface-item"
              style={{
                backgroundColor: selectedItem === intf.name ? 'rgba(37, 99, 235, 0.1)' : ''
              }}
            >
              <span className="interface-name">{intf.name}</span>
              <span className="interface-arrow">→</span>
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">
          {loading ? 'Cargando interfaces...' : 'No hay interfaces disponibles'}
        </div>
      )}
    </div>
  );
}

export default InterfaceList;