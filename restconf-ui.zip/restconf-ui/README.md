En  api.js ingresamos las credenciales del router que vamos a conectar
En vite.config.yang  configuramos la ip del server

